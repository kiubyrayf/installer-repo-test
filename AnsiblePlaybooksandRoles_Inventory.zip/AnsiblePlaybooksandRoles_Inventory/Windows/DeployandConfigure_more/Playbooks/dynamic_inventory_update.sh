#!/bin/bash

#ansible-inventory --list --yaml -i dynamic/dynamicmlkvcentervmware.yml --ask-vault-pass |  sed 's/_[[:xdigit:]]\{8\}-.*:/:/' > inventory/_dynamicmlk.yml
#ansible-inventory --list --yaml -i dynamic/dynamicvblockvmware.yml --ask-vault-pass |  sed 's/_[[:xdigit:]]\{8\}-.*:/:/' > inventory/_dynamicvblock.yml
#ansible-inventory --list --yaml -i dynamic/dynamic110hsavspvcsa03vmware.yml --ask-vault-pass |  sed 's/_[[:xdigit:]]\{8\}-.*:/:/' > inventory/_dynamicvcsa03.yml
#ansible-inventory --list --yaml -i dynamic/dynamic110hsavspvcsa04vmware.yml --ask-vault-pass |  sed 's/_[[:xdigit:]]\{8\}-.*:/:/' > inventory/_dynamicvcsa04.yml
#ansible-inventory --list --yaml -i dynamic/dynamic110hsavspvcsa05vmware.yml --ask-vault-pass |  sed 's/_[[:xdigit:]]\{8\}-.*:/:/' > inventory/_dynamicvcsa05.yml
ansible-inventory --list --yaml -i dynamic/dynamicdc1vcentervmware.yml --ask-vault-pass |  sed 's/_[[:xdigit:]]\{8\}-.*:/:/' > inventory/_dynamicdc1.yml
