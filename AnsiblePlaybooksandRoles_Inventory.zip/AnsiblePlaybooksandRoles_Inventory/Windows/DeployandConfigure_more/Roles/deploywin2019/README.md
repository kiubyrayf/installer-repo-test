#@description,This role is a wrapper for the deploywin role that builds a Windows 2016 VM from template
#@note,The documentation for deploywin would probably be more helpful to understand the steps
#@note,This playbook was written with the idea of one template per vCenter but should probably be udated to use a naming convention that specifies the cluster
#@note,The vm_template var controls which template gets used, override it using extra vars if you need a different one 
#@note,It seems simple to override vm_template on a per cluster basis but it's not.
#@note,If you override in cluster vars then you won't be able to deploy 2012 or SQL or 2016 images
#@note,You could probably run this against non-standard templates but no guarantees that it works
#@note,Non-standard templates should probably have a D drive at a minimum
#@var,vm_template,role vars or extra vars,The name of the template to deploy from
